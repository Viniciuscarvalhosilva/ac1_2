package com.example.pessoa.Repositores;



import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.pessoa.Models.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {
    @Query("select pp from Produto pp left join fetch pp.produtos c where pp.nome = :nome ")
    Produto findProdutosFetchProduto(@Param("nome") String nome);
    
    List<Produto> findByNome(String nome); 
    
    
    List<Produto> findByPrecoGreaterThan(Double preco); 
    List<Produto> findByPrecoLessThanEqual(Double preco); 
    List<Produto> findByNomeStartingWith(String prefix); 
}