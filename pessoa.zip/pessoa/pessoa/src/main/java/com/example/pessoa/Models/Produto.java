package com.example.pessoa.Models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor


public class Produto {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Long id;
private String nome;
private double preco;  
@ManyToOne
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;  

    
    

    
}
