package com.example.pessoa.Models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.pessoa.Models.Categoria;
import com.example.pessoa.Models.Produto;

import java.util.List;



@SpringBootApplication
public class PessoaApplication {

	@Bean
	public CommandLineRunner init(
			@Autowired com.example.pessoa.Repositores.CategoriaRepository CategoriaRepository,
			@Autowired com.example.pessoa.Repositores.ProdutoRepository ProdutoRepository) {
		return args -> {
	
			//Criar categorias
			Categoria categoria1 = new Categoria("bala");
			Categoria categoria2 = new Categoria("chocolate");
	
			System.out.println("*** CRIANDO OS PRODUTOS*");
			Produto c1 = ProdutoRepository.save(
					new Produto(0L, "coco", 70.00, null));
			Produto c2 = ProdutoRepository.save(
					new Produto(1L, "morango", 10.00, null));
			Produto c3 = ProdutoRepository.save(
					new Produto(2L, "uva", 80.00, null));
	
			System.out.println("*** PRODUTOS COM PREÇO MAIOR QUE 5000.00 ***");
			List<Produto> lista = ProdutoRepository.findByPrecoGreaterThan(50.00);
			lista.forEach(System.out::println);
	
			System.out.println("*** PRODUTOS COM PREÇO MENOR OU IGUAL A 5000.00 ***");
			List<Produto> listama = ProdutoRepository.findByPrecoLessThanEqual(50.00);
			listama.forEach(System.out::println);
	
			System.out.println("*** PRODUTOS COM NOME QUE COMEÇA COM 'R' ***");
			List<Produto> listame = ProdutoRepository.findByNomeStartingWith("R");
			listame.forEach(System.out::println);
	
		};
	}

		
	

	public static void main(String[] args) {
		SpringApplication.run(PessoaApplication.class, args);
	}}

